
import { useState } from 'react'
import './App.css'
import {Link} from "react-router-dom";
import { useEffect } from 'react'
function App({data}) {
  const [showScore, setshowScore]=useState(false)
  const [score,setscore] = useState(0)
  const [currentQuestion, setcurrentQuestion]=useState(0)

  const [options,setoptions] = useState(optionsCreator(0));
  const [timer,settimer] = useState(10);
  
  function optionsCreator(currentQuestion) {
    const incorrectAnswers = [...data[currentQuestion].incorrect_answers]; // Create a copy of incorrect_answers array
    const correctAnswer = data[currentQuestion].correct_answer;
    const randomIndex = Math.floor(Math.random() * (4)); // Get random index to insert correct answer
    incorrectAnswers.splice(randomIndex, 0, correctAnswer); // Insert correct answer at random index
    return incorrectAnswers;
  }

      
    function handleAnswerClick(option) {
      if (showScore || currentQuestion >= data.length) {
        return;
      }
    
      if (option === data[currentQuestion].correct_answer) {
        setscore(prevScore => prevScore + 1);
      }
    
      if (currentQuestion < data.length - 1) {
        setcurrentQuestion(prevQuestion => prevQuestion + 1);
        setoptions(optionsCreator(currentQuestion+1))
        settimer(10);
      } else {
        setshowScore(true);
      }
    }
    
  
    function handleRestart()
    {
      setshowScore(false);
      setscore(0);
      setcurrentQuestion(0);
      setoptions(optionsCreator(0));
      settimer(10);

    }
    useEffect(() => {
      let intervalId;
      if (timer > 0) {
        intervalId = setInterval(() => {
          settimer(prevTimer => prevTimer - 1);
        }, 1000);
      } else if (timer === 0) {
        handleAnswerClick(null); // Automatically submit answer when time runs out
      }
  
      // Clean up the interval when the component unmounts or when moving to the next question
      return () => clearInterval(intervalId);
    }, [timer, showScore, handleAnswerClick]);
 
  return (
    <div className='quiz'>
      <div className="score_container" style={{display:showScore?"block":"none"}}>
        <p>Your score is <br/><span>{score}/{data.length}</span></p>
        <div className="btn_container">
        <button onClick={handleRestart}>Restart</button>
        <Link to="/"><button>Home</button></Link>
        </div>
      </div>
    <div className="question_container" style={{display:showScore?"none":"block"}} >
      <h2 className='question'>Question {currentQuestion+1}</h2>
      <p>{data[currentQuestion].question}</p>
      <div className="option_container">
        {options.map((option,index)=>(
          <button key={index} onClick={()=>handleAnswerClick(option)}>{option}</button>
        ))}
      </div>
      <div className="timer">
        Time left:<span>    {timer}s</span>
      </div>
    </div>
  </div>
  )
  

  
  
}

export default App

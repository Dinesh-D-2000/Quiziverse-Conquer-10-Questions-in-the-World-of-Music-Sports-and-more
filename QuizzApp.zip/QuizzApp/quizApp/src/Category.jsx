import "./index.css";
import entertainment from "./Entertainment.json";
import {Link} from "react-router-dom";
import quizverse from "./assets/quizverse.png";






export const Category=()=>{
    
    return <div className="Home">
        <div className="quiz_icn_container">
        <img src={quizverse}></img>
        </div>
       

        <div className="menu_container">
            
       <Link to="/entertainment"> <button>Entertainment</button></Link>
       <Link to="/books"> <button>Books</button></Link>
       <Link to="/computers"> <button>Computers</button></Link>
       <Link to="/films"> <button>Films</button></Link>
       <Link to="/general_knowledge"> <button>General knowledge</button></Link>
       <Link to="/geography"> <button>Geography</button></Link>
       <Link to="/history"> <button>History</button></Link>
       <Link to="/mathematics"> <button>Mathematics</button></Link>
       <Link to="/music"> <button>Music</button></Link>
       <Link to="/mythology"> <button>Mythology</button></Link>
       <Link to="/politics"> <button>Politics</button></Link>
       <Link to="/science"> <button>Science</button></Link>
       <Link to="/sports"> <button>Sports</button></Link>
    
       
    </div>
    </div>
}
import { BrowserRouter, Route, Routes } from "react-router-dom"
import App from "./App"
import { Category } from "./Category"
import entertainment from "./Entertainment.json";
import books from "./Books.json";
import computers from "./Computers.json";
import films from "./Films.json";
import general_knowledge from "./General_knowledge.json";
import geography from "./Geography.json";
import history from "./History.json";
import mathematic from "./Mathematics.json";
import music from "./Music.json";
import mythology from "./Mythology.json";
import politics from "./Politics.json";
import science from "./Science.json";
import sports from "./Sports.json";

export const Home = () => {
    return (
        <BrowserRouter>
            <Routes>
                {/* Define routes using the <Route> component */}
                <Route path="/" element={<Category />} />
                <Route path="/entertainment" element={<App data={entertainment} />} />
                <Route path="/books" element={<App data={books} />} />
                <Route path="/computers" element={<App data={computers} />} />
                <Route path="/films" element={<App data={films} />} />
                <Route path="/general_knowledge" element={<App data={general_knowledge} />} />
                <Route path="/geography" element={<App data={geography} />} />
                <Route path="/history" element={<App data={history} />} />
                <Route path="/mathematics" element={<App data={mathematic} />} />
                <Route path="/music" element={<App data={music} />} />
                <Route path="/mythology" element={<App data={mythology} />} />
                <Route path="/politics" element={<App data={politics} />} />
                <Route path="/science" element={<App data={science} />} />
                <Route path="/sports" element={<App data={sports} />} />

            </Routes>
        </BrowserRouter>
    );
}